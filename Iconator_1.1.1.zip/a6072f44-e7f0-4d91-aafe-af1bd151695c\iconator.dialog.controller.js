//used for the icon picker dialog
angular.module("umbraco")
	.controller("Iconator.Dialog.Controller", function ($scope) {
	});
